$(function() {
    $("#send").click(updateGuests);
});

function updateGuests() {
    var first = $("#first").val();
    var last = $("#last").val();
    
    $.ajax("guest.ajax", {
		"type": "post",
		"data": {
        	"first": first,
                "last": last
		}
    }).done(displayGuests);
}

function displayGuests(data) {
    console.log(data);
    let list = $("<ol>"); // list = <ol> </ol>
    for(let  g of data){
        let item=$("<li>").text(g.first+" "+g.last); // item = <li>Romuald Pogo</li>
        list.append(item);  // list<ol> item = <li>Romuald Pogo</li> </ol>
    }

    $("#guestList").html(list);
    $("#first").val("");
    $("#last").val("");
}