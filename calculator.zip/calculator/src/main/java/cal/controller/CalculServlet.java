package cal.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CalculServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      Double addN1 = Double.valueOf(request.getParameter("add_num_1"));
      Double addN2 = Double.valueOf(request.getParameter("add_num_2"));
      // add attribute for JSP to use
      request.setAttribute("add_num_1", addN1);
      request.setAttribute("add_num_2", addN2);
      request.setAttribute("addR", addN1+addN2);

       addN1 = Double.valueOf(request.getParameter("mul_num_1"));
       addN2 = Double.valueOf(request.getParameter("mul_num_2"));
      // add attribute for JSP to use
      request.setAttribute("mul_num_1", addN1);
      request.setAttribute("mul_num_2", addN2);
      request.setAttribute("mulR", addN1*addN2);

      // initiate request dispatcher for JSP
        request.getRequestDispatcher("calcul.jsp").forward(request, response);;


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
